const fs=require('fs'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','app','src','main','assets','index.html'),'utf8');
function fail(msg,ctx={}){console.error('FAIL',JSON.stringify({msg,...ctx}));process.exit(1)}
function grab(name){const sig='function '+name+'(';let a=html.indexOf(sig);if(a<0)throw Error('missing '+name);let b=html.indexOf('{',a),d=0;for(let i=b;i<html.length;i++){if(html[i]==='{')d++;else if(html[i]==='}'&&--d===0)return html.slice(a,i+1)}throw Error('unclosed '+name)}
let texts=[];
function fakeCtx(){return {createLinearGradient(){return {addColorStop(){}}},fillRect(){},strokeRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fillText(s){texts.push(String(s))},set fillStyle(v){},set strokeStyle(v){},set lineWidth(v){},set textAlign(v){},set font(v){}}}
const canvas={width:0,height:0,getContext:()=>fakeCtx(),toDataURL:()=> 'data:image/png;base64,AA=='};
const ctx={console,Date,Math,JSON,document:{createElement:(tag)=>tag==='canvas'?canvas:{click(){},set href(v){},set download(v){}}},window:{Android:{saveBase64File(){}}},Android:{saveBase64File(){}},alert:()=>{},S:{event:{name:'VISUAL RESET TEST',date:'2026-09-27'},venues:[],tournaments:[],history:[],log:[]},clone:x=>JSON.parse(JSON.stringify(x)),save:()=>{}};
vm.createContext(ctx);
const names=['src','M','team','teamLabel','resolveSource','newMatch','lossCount','updateChampion','ensureOperationalMatches','buildBracket','sourceLabel','visualTournament','visualMatch','layoutBracketSection','downloadResultImage'];
// buildBracket references freezeBracketBlueprint; inject a real blueprint freezer without save side effects.
ctx.freezeBracketBlueprint=function(t){t.bracketBlueprint=t.matches.map(m=>{let z=JSON.parse(JSON.stringify(m));z.a=z.b=z.winner=z.loser=null;z.scoreA=z.scoreB=null;z.status='WAITING';z.courtId=z.courtName=null;z.checkinHold=false;return z});t.bracketBlueprintVersion=2};
vm.runInContext(names.map(grab).join('\n'),ctx);
function mk(){let t={id:'T',name:'Mens',teams:Array.from({length:8},(_,i)=>({id:'T'+(i+1),name:'TEAM '+(i+1),players:['P'+(i*2+1),'P'+(i*2+2)]})),matches:[],status:'setup'};ctx.S.tournaments=[t];return t}
function play(t,m,w){if(m.status!=='READY')fail('attempt to play non-READY',{game:m.no,status:m.status});m.winner=w;m.loser=w===m.a?m.b:m.a;m.scoreA=w===m.a?12:2;m.scoreB=w===m.b?12:2;m.status='DONE';m.courtId=m.courtName=null;ctx.ensureOperationalMatches(t)}
function renderTexts(t){texts=[];ctx.downloadResultImage(t);return texts.slice()}
let t=mk();ctx.buildBracket(t);
let safety=0;while(safety++<100){let gf=ctx.M(t,t.gfId);if(gf.status==='READY')break;let m=t.matches.filter(m=>m.status==='READY'&&!m.conditionalReset).sort((a,b)=>a.no-b.no)[0];if(!m)fail('stalled before GF');play(t,m,m.a)}
let g14=ctx.M(t,t.gfId);let aL=ctx.lossCount(t,g14.a),bL=ctx.lossCount(t,g14.b),wb=aL===0?g14.a:g14.b,lb=aL===1?g14.a:g14.b;if(!wb||!lb)fail('bad GF entrants');play(t,g14,wb);
let g15=ctx.M(t,t.resetId);
if(t.status!=='completed'||t.champion!==wb||g15.status!=='NOT_REQUIRED'||ctx.lossCount(t,lb)!==2)fail('no-reset engine state',{status:t.status,champion:t.champion,g15:g15.status,lbLoss:ctx.lossCount(t,lb)});
if(t.matches.some(m=>['READY','PLAYING','WAITING'].includes(m.status)))fail('actionable after no-reset completion');
let tx=renderTexts(t),joined=tx.join('\n');if(!joined.includes('FINAL RESULT')||!joined.includes('CHAMPION')||!joined.includes('NOT_REQUIRED')||!joined.includes('GAME 14  •  GRAND FINAL')||!joined.includes('GAME 15  •  GRAND FINAL RESET'))fail('no-reset rendered state');
ctx.ensureOperationalMatches(t);if(g15.status!=='NOT_REQUIRED'||t.matches.some(m=>['READY','PLAYING','WAITING'].includes(m.status)))fail('no-reset reactivated');
console.log('NO-RESET VISUAL + ENGINE PASS');
console.log(JSON.stringify({status:t.status,champion:t.champion,g15:g15.status,lbLosses:ctx.lossCount(t,lb)}));
