"""KATHANA TMS integrated-engine validation launcher.

The authoritative validation logic is validation/integrated_engine_validator.js.
That validator extracts and executes the actual bracket/state functions from
app/src/main/assets/index.html, so it cannot silently validate a separate
Python reimplementation of the tournament engine.
"""
from pathlib import Path
import subprocess, sys
root=Path(__file__).resolve().parent
validator=root/'validation'/'integrated_engine_validator.js'
proc=subprocess.run(['node',str(validator)],cwd=root)
sys.exit(proc.returncode)
