package com.kathana.tournament;

import android.app.*;
import android.os.*;
import android.webkit.*;
import android.graphics.Color;
import android.view.*;
import android.content.*;
import android.net.Uri;
import android.util.Base64;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView w;
    private static final int CREATE_FILE = 501;
    private static final int OPEN_FILE = 502;
    private byte[] pendingBytes;
    private String pendingMime = "application/octet-stream";
    private String pendingName = "KATHANA_TMS_Backup.json";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,9,10));
        getWindow().setNavigationBarColor(Color.rgb(7,9,10));
        if (Build.VERSION.SDK_INT >= 35) getWindow().getDecorView().setSystemUiVisibility(0);
        w = new WebView(this);
        setContentView(w);
        WebSettings s=w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        w.setWebViewClient(new WebViewClient()); w.setWebChromeClient(new WebChromeClient());
        w.addJavascriptInterface(new AndroidBridge(), "Android");
        w.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface public void saveTextFile(String name,String mime,String text){
            pendingBytes=text.getBytes(StandardCharsets.UTF_8); pendingMime=mime; pendingName=name; launchCreate();
        }
        @JavascriptInterface public void saveBase64File(String name,String mime,String base64){
            try { pendingBytes=Base64.decode(base64,Base64.DEFAULT); pendingMime=mime; pendingName=name; launchCreate(); }
            catch(Exception e){ toast("Unable to prepare file."); }
        }
        @JavascriptInterface public void openBackupFile(){ runOnUiThread(()->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json"); startActivityForResult(i,OPEN_FILE);
        }); }
    }

    private void launchCreate(){ runOnUiThread(()->{
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType(pendingMime); i.putExtra(Intent.EXTRA_TITLE,pendingName); startActivityForResult(i,CREATE_FILE);
    }); }
    private void toast(String s){ runOnUiThread(()->android.widget.Toast.makeText(this,s,android.widget.Toast.LENGTH_SHORT).show()); }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(requestCode==CREATE_FILE){
            try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(pendingBytes);out.flush();toast("File saved.");}
            catch(Exception e){toast("Save failed.");}
        } else if(requestCode==OPEN_FILE){
            try(InputStream in=getContentResolver().openInputStream(uri); ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n);
                String txt=new String(out.toByteArray(),StandardCharsets.UTF_8);
                String encoded=Base64.encodeToString(txt.getBytes(StandardCharsets.UTF_8),Base64.NO_WRAP);
                w.evaluateJavascript("window.KathanaRestore(decodeURIComponent(escape(atob('"+encoded+"'))))",null);
            } catch(Exception e){toast("Restore failed.");}
        }
    }
    @Override public void onBackPressed(){if(w.canGoBack())w.goBack();else super.onBackPressed();}
}
