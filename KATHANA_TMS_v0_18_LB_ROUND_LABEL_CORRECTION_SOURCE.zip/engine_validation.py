"""KATHANA TMS v0.18 synchronized release validator.

Independent release gate: retains literal canonical N=4/N=8 feeder maps and
requires the production-engine validator plus both visual/engine GF regressions.
The production engine remains app/src/main/assets/index.html; this file does not
implement a second tournament-routing engine.
"""
from pathlib import Path
import subprocess, sys, re, json
ROOT=Path(__file__).resolve().parent
HTML=ROOT/'app/src/main/assets/index.html'
text=HTML.read_text(encoding='utf-8')
GOLDEN={
4:[[1,'T1','T2','WB',''],[2,'T3','T4','WB',''],[3,'W1','W2','WB',''],[4,'L1','L2','LB',''],[5,'W4','L3','LB',''],[6,'W3','W5','GF',''],[7,'W6','L6','GF','RESET']],
8:[[1,'T1','T2','WB',''],[2,'T3','T4','WB',''],[3,'T5','T6','WB',''],[4,'T7','T8','WB',''],[5,'W1','W2','WB',''],[6,'W3','W4','WB',''],[7,'W5','W6','WB',''],[8,'L1','L2','LB',''],[9,'L3','L4','LB',''],[10,'W8','L6','LB',''],[11,'W9','L5','LB',''],[12,'W10','W11','LB',''],[13,'W12','L7','LB',''],[14,'W7','W13','GF',''],[15,'W14','L14','GF','RESET']]
}
# Independent immutable expectations are deliberately present here, separate
# from the JS validator, so accidental validator drift is reviewable.
assert GOLDEN[8][9][1:3]==['W8','L6'] and GOLDEN[8][10][1:3]==['W9','L5']
assert GOLDEN[8][11][1:3]==['W10','W11'] and GOLDEN[8][12][1:3]==['W12','L7']
if re.search(r'cur\s*=\s*wbLosers\.slice\s*\(',text): raise SystemExit('FAIL stale flat-LB construction')
if 'wbDropStages' not in text: raise SystemExit('FAIL stage-coupled construction missing')
if "gfDone?'NOT_REQUIRED':'INACTIVE'" not in text: raise SystemExit('FAIL Reset terminal-state rule missing')
checks=[
 ('integrated production engine',ROOT/'validation/integrated_engine_validator.js'),
 ('no-reset visual + engine',ROOT/'validation/no_reset_visual_validator.js'),
 ('reset-required visual + engine',ROOT/'validation/reset_visual_validator.js'),
]
for label,p in checks:
    r=subprocess.run(['node',str(p)],cwd=ROOT,text=True,capture_output=True)
    sys.stdout.write(r.stdout); sys.stderr.write(r.stderr)
    if r.returncode: raise SystemExit(f'FAIL {label}')
print('SYNCHRONIZED VALIDATOR PASS')
print('Independent literal golden expectations retained: N=4, N=8')
