const fs=require('fs'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','app','src','main','assets','index.html'),'utf8');
if(/cur\s*=\s*wbLosers\.slice\s*\(/.test(html)) throw new Error('FAIL: stale flat-LB path cur=wbLosers.slice() still present');
if(!html.includes('wbDropStages')) throw new Error('FAIL: stage-coupled WB drop construction marker missing');
function grab(name){const sig='function '+name+'(';let a=html.indexOf(sig);if(a<0)throw Error('missing '+name);let b=html.indexOf('{',a),d=0;for(let i=b;i<html.length;i++){if(html[i]==='{')d++;else if(html[i]==='}'&&--d===0)return html.slice(a,i+1)}throw Error('unclosed '+name)}
const code=[grab('src'),grab('newMatch'),grab('buildBracket')].join('\n');
const ctx={ensureOperationalMatches:()=>{},freezeBracketBlueprint:()=>{}};vm.createContext(ctx);vm.runInContext(code,ctx);
function token(x){if(x.kind==='TEAM')return x.id;let m=/:(WB|LB|GF):/.test(x.id)?x.id:null;return (x.kind==='WIN'?'W':'L')+ctx._num[x.id]}
function generated(n){let t={id:'T',teams:Array.from({length:n},(_,i)=>({id:'T'+(i+1)})),byeTeamId:null};ctx.buildBracket(t);ctx._num=Object.fromEntries(t.matches.map(m=>[m.id,m.no]));return t.matches.map(m=>[m.no,token(m.aSrc),token(m.bSrc),m.bracket,m.conditionalReset?'RESET':'']).sort((a,b)=>a[0]-b[0])}
const GOLD={
4:[[1,'T1','T2','WB',''],[2,'T3','T4','WB',''],[3,'W1','W2','WB',''],[4,'L1','L2','LB',''],[5,'W4','L3','LB',''],[6,'W3','W5','GF',''],[7,'W6','L6','GF','RESET']],
8:[[1,'T1','T2','WB',''],[2,'T3','T4','WB',''],[3,'T5','T6','WB',''],[4,'T7','T8','WB',''],[5,'W1','W2','WB',''],[6,'W3','W4','WB',''],[7,'W5','W6','WB',''],[8,'L1','L2','LB',''],[9,'L3','L4','LB',''],[10,'W8','L6','LB',''],[11,'W9','L5','LB',''],[12,'W10','W11','LB',''],[13,'W12','L7','LB',''],[14,'W7','W13','GF',''],[15,'W14','L14','GF','RESET']]
};
for(const n of [4,8]){const got=generated(n),exp=GOLD[n];if(JSON.stringify(got)!==JSON.stringify(exp)){console.error('GOLDEN FAIL N='+n);console.error('EXPECTED',JSON.stringify(exp));console.error('ACTUAL  ',JSON.stringify(got));process.exit(1)}console.log('GOLDEN PASS N='+n)}
// Independent guard: inspect generated N=8 topology, not generator internals.
const g8=generated(8);const g12=g8.find(x=>x[0]===12),g13=g8.find(x=>x[0]===13);if(JSON.stringify(g12.slice(1,3))!==JSON.stringify(['W10','W11'])||JSON.stringify(g13.slice(1,3))!==JSON.stringify(['W12','L7']))throw Error('FINAL-DROP CONSOLIDATION GUARD FAIL');
console.log('FINAL-DROP CONSOLIDATION GUARD PASS');
