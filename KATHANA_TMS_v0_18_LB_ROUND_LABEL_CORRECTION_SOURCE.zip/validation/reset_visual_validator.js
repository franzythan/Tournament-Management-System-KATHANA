const fs=require('fs'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','app','src','main','assets','index.html'),'utf8');
function fail(msg,ctx={}){console.error('FAIL',JSON.stringify({msg,...ctx}));process.exit(1)}
function grab(name){const sig='function '+name+'(';let a=html.indexOf(sig);if(a<0)throw Error('missing '+name);let b=html.indexOf('{',a),d=0;for(let i=b;i<html.length;i++){if(html[i]==='{')d++;else if(html[i]==='}'&&--d===0)return html.slice(a,i+1)}throw Error('unclosed '+name)}
let texts=[];
function fakeCtx(){return {createLinearGradient(){return {addColorStop(){}}},fillRect(){},strokeRect(){},beginPath(){},moveTo(){},lineTo(){},stroke(){},fillText(s){texts.push(String(s))},set fillStyle(v){},set strokeStyle(v){},set lineWidth(v){},set textAlign(v){},set font(v){}}}
const canvas={width:0,height:0,getContext:()=>fakeCtx(),toDataURL:()=> 'data:image/png;base64,AA=='};
const ctx={console,Date,Math,JSON,document:{createElement:(tag)=>tag==='canvas'?canvas:{click(){},set href(v){},set download(v){}}},window:{Android:{saveBase64File(){}}},Android:{saveBase64File(){}},alert:()=>{},S:{event:{name:'VISUAL RESET TEST',date:'2026-09-27'},venues:[],tournaments:[],history:[],log:[]},clone:x=>JSON.parse(JSON.stringify(x)),save:()=>{}};
vm.createContext(ctx);
const names=['src','M','team','teamLabel','resolveSource','newMatch','lossCount','updateChampion','ensureOperationalMatches','buildBracket','sourceLabel','loserDisplayRound','displayMatchLabel','visualTournament','visualMatch','layoutBracketSection','downloadResultImage'];
// buildBracket references freezeBracketBlueprint; inject a real blueprint freezer without save side effects.
ctx.freezeBracketBlueprint=function(t){t.bracketBlueprint=t.matches.map(m=>{let z=JSON.parse(JSON.stringify(m));z.a=z.b=z.winner=z.loser=null;z.scoreA=z.scoreB=null;z.status='WAITING';z.courtId=z.courtName=null;z.checkinHold=false;return z});t.bracketBlueprintVersion=2};
vm.runInContext(names.map(grab).join('\n'),ctx);
function mk(){let t={id:'T',name:'Mens',teams:Array.from({length:8},(_,i)=>({id:'T'+(i+1),name:'TEAM '+(i+1),players:['P'+(i*2+1),'P'+(i*2+2)]})),matches:[],status:'setup'};ctx.S.tournaments=[t];return t}
function play(t,m,w){if(m.status!=='READY')fail('attempt to play non-READY',{game:m.no,status:m.status});m.winner=w;m.loser=w===m.a?m.b:m.a;m.scoreA=w===m.a?12:2;m.scoreB=w===m.b?12:2;m.status='DONE';m.courtId=m.courtName=null;ctx.ensureOperationalMatches(t)}
function renderTexts(t){texts=[];ctx.downloadResultImage(t);return texts.slice()}
let t=mk();ctx.buildBracket(t);
// Deterministically finish all pre-GF matches. At G14 choose the one-loss LB finalist to force reset.
let safety=0;while(safety++<100){let gf=ctx.M(t,t.gfId);if(gf.status==='READY')break;let m=t.matches.filter(m=>m.status==='READY'&&!m.conditionalReset).sort((a,b)=>a.no-b.no)[0];if(!m)fail('stalled before GF');play(t,m,m.a)}
let g14=ctx.M(t,t.gfId);let aL=ctx.lossCount(t,g14.a),bL=ctx.lossCount(t,g14.b),wb=aL===0?g14.a:g14.b,lb=aL===1?g14.a:g14.b;if(!wb||!lb)fail('bad GF entrants',{a:g14.a,aL,b:g14.b,bL});play(t,g14,lb);
let g15=ctx.M(t,t.resetId);
if(g14.status!=='DONE'||ctx.lossCount(t,wb)!==1||ctx.lossCount(t,lb)!==1||t.champion!==null||t.status!=='active'||g15.status!=='READY'||g15.a!==g14.winner||g15.b!==g14.loser)fail('post-G14 engine state',{g14:g14.status,wbLoss:ctx.lossCount(t,wb),lbLoss:ctx.lossCount(t,lb),champion:t.champion,status:t.status,g15:g15.status,a:g15.a,b:g15.b,expectedA:g14.winner,expectedB:g14.loser});
let tx=renderTexts(t),joined=tx.join('\n');
if(!joined.includes('TOURNAMENT ONGOING'))fail('render prematurely final',{});if(joined.includes('CHAMPION'))fail('render prematurely champion',{});if(!joined.includes('GAME 14  •  GRAND FINAL')||!joined.includes('GAME 15  •  GRAND FINAL RESET'))fail('GF boxes missing');if(!joined.includes('READY'))fail('G15 READY not rendered');if(joined.includes('NOT_REQUIRED'))fail('G15 wrongly NOT_REQUIRED');
// Complete reset, then verify final engine + rendered state.
play(t,g15,g15.a);
if(g15.status!=='DONE'||t.champion!==g15.winner||ctx.lossCount(t,g15.loser)!==2||t.status!=='completed')fail('post-G15 engine state',{status:g15.status,champion:t.champion,winner:g15.winner,loserLoss:ctx.lossCount(t,g15.loser),tour:t.status});
if(t.matches.some(m=>['READY','PLAYING','WAITING'].includes(m.status)))fail('actionable after completion');
tx=renderTexts(t);joined=tx.join('\n');if(!joined.includes('FINAL RESULT')||!joined.includes('CHAMPION')||!joined.includes('GAME 15  •  GRAND FINAL RESET')||!joined.includes('DONE'))fail('post-G15 render state');
console.log('RESET-REQUIRED VISUAL + ENGINE PASS');
console.log(JSON.stringify({postG14:{status:'active',champion:null,g15:'READY',participants:[g14.winner,g14.loser]},postG15:{status:t.status,champion:t.champion,g15:g15.status,loserLosses:ctx.lossCount(t,g15.loser)}}));
