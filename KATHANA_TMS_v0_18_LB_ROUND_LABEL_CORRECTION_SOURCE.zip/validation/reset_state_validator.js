const fs=require('fs'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','app','src','main','assets','index.html'),'utf8');
if(html.includes("if(!needed){if(m.status!=='WAITING'||m.courtId){m.status='WAITING'")) throw Error('FAIL: old unused-reset -> WAITING path still present');
if(!html.includes("gfDone?'NOT_REQUIRED':'INACTIVE'")) throw Error('FAIL: explicit reset terminal states missing');
function grab(name){const sig='function '+name+'(';let a=html.indexOf(sig);if(a<0)throw Error('missing '+name);let b=html.indexOf('{',a),d=0;for(let i=b;i<html.length;i++){if(html[i]==='{')d++;else if(html[i]==='}'&&--d===0)return html.slice(a,i+1)}throw Error('unclosed '+name)}
const names=['src','M','resolveSource','newMatch','lossCount','updateChampion','ensureOperationalMatches','buildBracket'];
const code=names.map(grab).join('\n');
const ctx={freezeBracketBlueprint:()=>{}};vm.createContext(ctx);vm.runInContext(code,ctx);
function mk(){return {id:'T',teams:Array.from({length:4},(_,i)=>({id:'T'+(i+1)})),byeTeamId:null,matches:[],status:'setup'};}
function byNo(t,n){return t.matches.find(m=>m.no===n)}
function play(t,n,winnerId){const m=byNo(t,n);if(!m)throw Error('missing G'+n);ctx.ensureOperationalMatches(t);if(m.status!=='READY'&&m.status!=='PLAYING')throw Error('G'+n+' not actionable: '+m.status);if(winnerId!==m.a&&winnerId!==m.b)throw Error('winner not participant G'+n);m.winner=winnerId;m.loser=winnerId===m.a?m.b:m.a;m.scoreA=winnerId===m.a?11:2;m.scoreB=winnerId===m.b?11:2;m.status='DONE';m.courtId=m.courtName=null;ctx.ensureOperationalMatches(t);}
function actionable(t){return t.matches.filter(m=>['READY','PLAYING','WAITING'].includes(m.status));}
function assert(cond,msg){if(!cond)throw Error(msg)}
function setupToGF(){let t=mk();ctx.buildBracket(t);assert(byNo(t,7).status==='INACTIVE','G7 initial state '+byNo(t,7).status);play(t,1,'T1');play(t,2,'T3');play(t,3,'T1');play(t,4,'T2');play(t,5,'T2');assert(byNo(t,6).status==='READY','G6 not READY');return t}
// No-reset path: undefeated WB champion T1 wins G6.
let a=setupToGF();play(a,6,'T1');let r=byNo(a,7);assert(a.champion==='T1','no-reset champion');assert(a.status==='completed','no-reset tournament '+a.status);assert(r.status==='NOT_REQUIRED','no-reset reset state '+r.status);assert(!r.courtId&&!r.courtName&&!r.readyAt,'inactive reset retained operational fields');assert(actionable(a).length===0,'no-reset actionable matches='+actionable(a).map(x=>x.no+':'+x.status));ctx.ensureOperationalMatches(a);assert(r.status==='NOT_REQUIRED'&&actionable(a).length===0,'completed tournament regenerated actionable reset');console.log('N=4 NO-RESET STATE PASS');
// Reset-required path: LB champion T2 wins G6, activating G7; no champion until G7.
let b=setupToGF();play(b,6,'T2');r=byNo(b,7);assert(!b.champion,'champion declared before reset');assert(b.status==='active','reset-required tournament '+b.status);assert(ctx.lossCount(b,'T1')===1&&ctx.lossCount(b,'T2')===1,'finalists not at one loss each');assert(r.status==='READY','G7 not READY: '+r.status);assert(r.a&&r.b,'G7 feeders unresolved');play(b,7,'T1');assert(b.champion==='T1','reset winner not champion');assert(b.status==='completed','reset tournament not completed');assert(ctx.lossCount(b,'T2')===2,'reset loser does not have second loss');assert(actionable(b).length===0,'post-reset actionable matches remain');ctx.ensureOperationalMatches(b);assert(actionable(b).length===0,'completed reset tournament generated additional matches');console.log('N=4 RESET-REQUIRED STATE PASS');
