const fs=require('fs'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','app','src','main','assets','index.html'),'utf8');
function grab(name){const sig='function '+name+'(';let a=html.indexOf(sig);if(a<0)throw Error('missing '+name);let b=html.indexOf('{',a),d=0;for(let i=b;i<html.length;i++){if(html[i]==='{')d++;else if(html[i]==='}'&&--d===0)return html.slice(a,i+1)}throw Error('unclosed '+name)}
const code=[grab('src'),grab('newMatch'),grab('buildBracket'),grab('loserDisplayRound'),grab('displayMatchLabel')].join('\n');
const ctx={ensureOperationalMatches:()=>{},freezeBracketBlueprint:(t)=>{t.bracketBlueprint=JSON.parse(JSON.stringify(t.matches))}};vm.createContext(ctx);vm.runInContext(code,ctx);
function make(n,byeIndex=0){let t={id:'T'+n,teams:Array.from({length:n},(_,i)=>({id:'T'+(i+1)})),byeTeamId:n%2?'T'+(byeIndex+1):null};ctx.buildBracket(t);return t}
function assert(cond,msg){if(!cond)throw Error(msg)}
for(let n=4;n<=30;n++){
 const selections=n%2?n:1;
 for(let bi=0;bi<selections;bi++){
  const t=make(n,bi), lbs=t.matches.filter(m=>m.bracket==='LB').sort((a,b)=>a.no-b.no);
  const rounds=lbs.map(m=>ctx.loserDisplayRound(t,m));
  const uniq=[...new Set(rounds)].sort((a,b)=>a-b);
  assert(uniq.every((r,i)=>r===i+1),`N=${n} bye=${bi+1}: skipped/artificial rounds ${uniq}`);
  for(const r of uniq){const stage=lbs.filter(m=>ctx.loserDisplayRound(t,m)===r);assert(stage.every(m=>ctx.displayMatchLabel(t,m)===`LOSERS R${r}`),`N=${n}: inconsistent R${r}`)}
  // Display-only: stored engine labels/round fields remain untouched and route IDs remain intact.
  const before=lbs.map(m=>[m.id,m.round,m.aSrc,m.bSrc,m.status]);lbs.forEach(m=>ctx.displayMatchLabel(t,m));const after=lbs.map(m=>[m.id,m.round,m.aSrc,m.bSrc,m.status]);assert(JSON.stringify(before)===JSON.stringify(after),`N=${n}: display label mutated engine state`);
 }
}
const t6=make(6);const got=t6.matches.filter(m=>m.bracket==='LB').map(m=>[`G${m.no}`,ctx.displayMatchLabel(t6,m)]);const exp=[['G6','LOSERS R1'],['G7','LOSERS R1'],['G8','LOSERS R2'],['G9','LOSERS R3']];assert(JSON.stringify(got)===JSON.stringify(exp),'N=6 expected display mismatch: '+JSON.stringify(got));
console.log('LB LABEL VALIDATION PASS N=4-30 (all odd-N BYE selections)');
console.log('N=6 DISPLAY '+got.map(x=>x.join('=')).join(' | '));
console.log('DISPLAY-ONLY STATE IMMUTABILITY PASS');
