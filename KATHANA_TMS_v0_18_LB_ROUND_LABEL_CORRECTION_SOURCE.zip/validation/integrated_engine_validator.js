const fs=require('fs'),vm=require('vm'),path=require('path');
const html=fs.readFileSync(path.join(__dirname,'..','app','src','main','assets','index.html'),'utf8');
function fail(msg,ctx={}){console.error('FAIL',JSON.stringify({msg,...ctx}));process.exit(1)}
if(/cur\s*=\s*wbLosers\.slice\s*\(/.test(html)) fail('stale flat-LB construction present');
if(!html.includes('wbDropStages')) fail('stage-coupled marker missing');
if(html.includes("if(!needed){if(m.status!=='WAITING'||m.courtId){m.status='WAITING'")) fail('old unused Reset -> WAITING path present');
if(!html.includes("gfDone?'NOT_REQUIRED':'INACTIVE'")) fail('explicit Reset terminal state missing');
function grab(name){const sig='function '+name+'(';let a=html.indexOf(sig);if(a<0)throw Error('missing '+name);let b=html.indexOf('{',a),d=0;for(let i=b;i<html.length;i++){if(html[i]==='{')d++;else if(html[i]==='}'&&--d===0)return html.slice(a,i+1)}throw Error('unclosed '+name)}
const names=['src','M','resolveSource','newMatch','lossCount','updateChampion','ensureOperationalMatches','buildBracket'];
const ctx={freezeBracketBlueprint:()=>{}};vm.createContext(ctx);vm.runInContext(names.map(grab).join('\n'),ctx);
function mk(n,bye=null){return {id:'T',teams:Array.from({length:n},(_,i)=>({id:'T'+(i+1)})),byeTeamId:bye,matches:[],status:'setup'};}
function tok(t,s){if(s.kind==='TEAM')return s.id;let m=ctx.M(t,s.id);return (s.kind==='WIN'?'W':'L')+m.no}
const GOLD={
4:[[1,'T1','T2','WB',''],[2,'T3','T4','WB',''],[3,'W1','W2','WB',''],[4,'L1','L2','LB',''],[5,'W4','L3','LB',''],[6,'W3','W5','GF',''],[7,'W6','L6','GF','RESET']],
8:[[1,'T1','T2','WB',''],[2,'T3','T4','WB',''],[3,'T5','T6','WB',''],[4,'T7','T8','WB',''],[5,'W1','W2','WB',''],[6,'W3','W4','WB',''],[7,'W5','W6','WB',''],[8,'L1','L2','LB',''],[9,'L3','L4','LB',''],[10,'W8','L6','LB',''],[11,'W9','L5','LB',''],[12,'W10','W11','LB',''],[13,'W12','L7','LB',''],[14,'W7','W13','GF',''],[15,'W14','L14','GF','RESET']]
};
function topology(n){let t=mk(n);ctx.buildBracket(t);return t.matches.map(m=>[m.no,tok(t,m.aSrc),tok(t,m.bSrc),m.bracket,m.conditionalReset?'RESET':'']);}
for(const n of [4,8]){let got=topology(n);if(JSON.stringify(got)!==JSON.stringify(GOLD[n]))fail('literal golden mismatch',{n,got,expected:GOLD[n]});console.log(`GOLDEN PASS N=${n}`)}
let g8=topology(8),g12=g8.find(x=>x[0]===12),g13=g8.find(x=>x[0]===13);if(JSON.stringify(g12.slice(1,3))!==JSON.stringify(['W10','W11'])||JSON.stringify(g13.slice(1,3))!==JSON.stringify(['W12','L7']))fail('final-drop consolidation guard');console.log('FINAL-DROP CONSOLIDATION GUARD PASS');
function assertStaticGraph(t,n,bye){
 const opening=t.matches.filter(m=>m.bracket==='WB'&&m.round===1); if(opening.length!==Math.floor(n/2)) fail('opening match count',{n,bye,got:opening.length});
 if(n%2){if(t.openingWaiting!==bye)fail('selected BYE not direct-advanced',{n,bye,actual:t.openingWaiting});if(opening.some(m=>m.aSrc.id===bye||m.bSrc.id===bye))fail('BYE team appears in opening match',{n,bye});}
 const ids=new Set(t.matches.map(m=>m.id)); for(const m of t.matches)for(const s of [m.aSrc,m.bSrc])if(s.kind!=='TEAM'&&!ids.has(s.id))fail('orphan feeder',{n,bye,game:m.no,source:s});
 for(const w of t.matches.filter(m=>m.bracket==='WB')){let uses=t.matches.filter(m=>m.bracket==='LB'&&[m.aSrc,m.bSrc].some(s=>s.kind==='LOSE'&&s.id===w.id));if(uses.length!==1)fail('WB loser destination count',{n,bye,wbGame:w.no,count:uses.length});}
}
function active(t){return t.matches.filter(m=>['READY','PLAYING'].includes(m.status));}
function actionable(t){return t.matches.filter(m=>['READY','PLAYING','WAITING'].includes(m.status));}
function checkState(t,n,bye){
 ctx.ensureOperationalMatches(t);
 let seen=new Map(); for(const m of active(t)){if(!m.a||!m.b)fail('unresolved feeder actionable',{n,bye,game:m.no,status:m.status});if(m.a===m.b)fail('self-match',{n,bye,game:m.no});for(const x of [m.a,m.b]){if(ctx.lossCount(t,x)>=2)fail('eliminated team active',{n,bye,team:x,game:m.no});if(seen.has(x))fail('simultaneously actionable team',{n,bye,team:x,games:[seen.get(x),m.no]});seen.set(x,m.no)}}
}
function play(t,m,w){if(!['READY','PLAYING'].includes(m.status))throw Error('non-actionable G'+m.no+' '+m.status);if(w!==m.a&&w!==m.b)throw Error('winner not participant');m.winner=w;m.loser=w===m.a?m.b:m.a;m.scoreA=w===m.a?11:2;m.scoreB=w===m.b?11:2;m.status='DONE';m.courtId=m.courtName=null;ctx.ensureOperationalMatches(t)}
function run(n,bye,forceReset,strategy){
 let t=mk(n,bye);ctx.buildBracket(t);assertStaticGraph(t,n,bye); if(n%2&&ctx.lossCount(t,bye)!==0)fail('BYE recorded loss',{n,bye});
 let played=0,safety=0; while(t.status!=='completed'&&safety++<1000){checkState(t,n,bye);let rs=active(t).filter(m=>m.status==='READY').sort((a,b)=>a.no-b.no);if(!rs.length)fail('no READY before completion',{n,bye,forceReset,strategy});let m=strategy===1?rs[rs.length-1]:rs[0];let w;
   if(m.id===t.gfId){let aL=ctx.lossCount(t,m.a),bL=ctx.lossCount(t,m.b),wb=aL===0?m.a:bL===0?m.b:null,lb=aL===1?m.a:bL===1?m.b:null;if(!wb||!lb)fail('GF entrant loss state',{n,bye,a:m.a,aL,b:m.b,bL});w=forceReset?lb:wb}
   else w=((m.no+strategy)%2===0)?m.a:m.b;
   let loser=w===m.a?m.b:m.a,before=ctx.lossCount(t,loser);play(t,m,w);played++;let after=ctx.lossCount(t,loser);if(after!==before+1)fail('loss increment',{n,bye,game:m.no});if(after===1&&t.status==='completed'&&t.champion!==loser)fail('first-loss elimination/completion inconsistency',{n,bye,game:m.no,loser});
 }
 if(safety>=1000)fail('safety loop',{n,bye});
 let reset=ctx.M(t,t.resetId),expected=2*n-2+(forceReset?1:0);if(played!==expected)fail('played-game invariant',{n,bye,forceReset,played,expected});
 if(forceReset){if(reset.status!=='DONE')fail('required Reset not DONE',{n,bye,status:reset.status});if(ctx.lossCount(t,t.champion)!==1)fail('reset champion losses',{n,bye,losses:ctx.lossCount(t,t.champion)})}
 else {if(reset.status!=='NOT_REQUIRED')fail('unused Reset terminal state',{n,bye,status:reset.status});if(reset.courtId||reset.courtName||reset.readyAt)fail('unused Reset operational fields',{n,bye});if(ctx.lossCount(t,t.champion)!==0)fail('no-reset champion losses',{n,bye,losses:ctx.lossCount(t,t.champion)})}
 for(const tm of t.teams)if(tm.id!==t.champion&&ctx.lossCount(t,tm.id)!==2)fail('non-champion not exactly 2 losses',{n,bye,team:tm.id,losses:ctx.lossCount(t,tm.id)});
 if(actionable(t).length)fail('actionable matches after completion',{n,bye,matches:actionable(t).map(m=>[m.no,m.status])});ctx.ensureOperationalMatches(t);if(actionable(t).length)fail('reactivated after completion',{n,bye});
 return played;
}
let rows=[],runs=0;for(let n=4;n<=30;n++){let byes=n%2?Array.from({length:n},(_,i)=>'T'+(i+1)):[null];for(const bye of byes)for(const forceReset of [false,true])for(const strategy of [0,1]){run(n,bye,forceReset,strategy);runs++}rows.push({n,opening:Math.floor(n/2),bye:n%2?1:0,byeSelections:n%2?n:0,noReset:2*n-2,reset:2*n-1,result:'PASS'});}
console.log('INTEGRATED ENGINE PASS runs='+runs);console.log(JSON.stringify(rows));
