from dataclasses import dataclass
from random import Random

@dataclass(frozen=True)
class S:
    kind:str; id:str
@dataclass
class M:
    id:str;br:str;r:int;i:int;a:S;b:S;winner:str=None;loser:str=None;done:bool=False;conditional:bool=False

def gen(n, bye=None):
    teams=[f'T{i+1}' for i in range(n)]
    if n%2:
        bye=bye or teams[-1]
        teams=[x for x in teams if x!=bye]+[bye]
    matches=[]; seq=0
    def nm(br,r,i,a,b,cond=False):
        nonlocal seq
        seq+=1;m=M(f'M{seq}',br,r,i,a,b,conditional=cond);matches.append(m);return m
    cur=[S('TEAM',x) for x in teams]; wb_los=[];r=1
    while len(cur)>1:
        nxt=[]; pairs=len(cur)//2
        for i in range(pairs):
            m=nm('WB',r,i,cur[2*i],cur[2*i+1]);nxt.append(S('WIN',m.id));wb_los.append(S('LOSE',m.id))
        if len(cur)%2:nxt.append(cur[-1])
        cur=nxt;r+=1
    wbchamp=cur[0]
    cur=wb_los;r=1
    while len(cur)>1:
        nxt=[]
        for i in range(len(cur)//2):
            m=nm('LB',r,i,cur[2*i],cur[2*i+1]);nxt.append(S('WIN',m.id))
        if len(cur)%2:nxt.append(cur[-1])
        cur=nxt;r+=1
    lbchamp=cur[0]
    gf=nm('GF',1,0,wbchamp,lbchamp)
    reset=nm('GF',2,0,S('WIN',gf.id),S('LOSE',gf.id),True)
    return teams,matches,gf,reset

def sim(n,seed,force_reset=False,bye=None):
    teams,ms,gf,reset=gen(n,bye)
    by={m.id:m for m in ms}; losses={t:0 for t in teams}; rng=Random(seed)
    def res(s):
        if s.kind=='TEAM':return s.id
        m=by[s.id]
        if not m.done:return None
        return m.winner if s.kind=='WIN' else m.loser
    played=[]; reset_required=False
    while True:
        ready=[]
        for m in ms:
            if m.done:continue
            if m.conditional:
                if not gf.done:continue
                # reset only when GF winner entered with one loss and WB champ got first loss
                a,b=res(m.a),res(m.b)
                if not a or not b or not (losses[a]==1 and losses[b]==1):continue
            a,b=res(m.a),res(m.b)
            if a and b:ready.append((m,a,b))
        if not ready:break
        # A team must never be present in two simultaneously active/ready matches.
        seen_ready={}
        for mm,aa,bb in ready:
            if aa==bb:return False,'self match',None
            for tt in (aa,bb):
                if tt in seen_ready:return False,f'double active {tt} in {seen_ready[tt]} and {mm.id}',None
                seen_ready[tt]=mm.id
        # random completion order among ready
        m,a,b=rng.choice(ready)
        # no team in another unresolved active match is implicit source graph; verify participants not eliminated
        if losses[a]>=2 or losses[b]>=2: return False,'eliminated participant',None
        if m is gf:
            # Force either championship path for validation. Pre-GF: WB finalist has 0 losses, LB finalist has 1.
            wb = a if losses[a]==0 else b if losses[b]==0 else None
            lb = a if losses[a]==1 else b if losses[b]==1 else None
            if not wb or not lb:return False,'GF loss state',None
            w,l=(lb,wb) if force_reset else (wb,lb)
        else:
            w,l=(a,b) if rng.random()<.5 else (b,a)
        m.winner,m.loser,m.done=w,l,True;losses[l]+=1;played.append(m.id)
        if m is gf: reset_required=(losses[w]==1 and losses[l]==1)
        if m is gf and losses[l]>=2:
            # no reset required; stop
            break
        if m is reset:break
    champ = by[played[-1]].winner if played else None
    # invariants
    if not gf.done:return False,'GF not done',None
    need_reset=reset_required
    if need_reset != reset.done:return False,f'reset mismatch {need_reset} {reset.done}',None
    expected=2*n-1 if reset.done else 2*n-2
    if len(played)!=expected:return False,f'game count {len(played)} != {expected}',None
    if losses[champ]>=2:return False,'champ 2 losses',None
    for t in teams:
        if t!=champ and losses[t]!=2:return False,f'{t} losses {losses[t]}',None
    return True,'ok',(len(played),reset.done)

cases=0
for n in range(4,31):
    byes=[None] if n%2==0 else [f'T{i+1}' for i in range(n)]
    for bye in byes:
        for seed in range(50):
            for reset_case in (False,True):
                ok,msg,_=sim(n,seed,reset_case,bye)
                cases+=1
                if not ok: raise SystemExit((n,bye,seed,reset_case,msg))
print('PASS',cases,'simulations across team counts 4-30 and every manual opening-BYE choice for odd counts')
